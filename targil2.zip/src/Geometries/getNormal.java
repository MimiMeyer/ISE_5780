package Geometries;

import Primitives.Point3D;
import Primitives.Vector;

public interface getNormal {
    Vector getNormal(Point3D point);
}

package Geometries;

import Primitives.Point3D;

public class Triangle extends Polygon {
    public Triangle(Point3D... vertices) {
        super(vertices);
    }
}
